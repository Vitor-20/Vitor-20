public class Configuracao {
    private static final Configuracao INSTANCE = new Configuracao();

    private Configuracao() {
        // Construtor privado para evitar instanciamento externo
    }

    public static Configuracao getInstance() {
        return INSTANCE;
    }

    // ... outros métodos
}