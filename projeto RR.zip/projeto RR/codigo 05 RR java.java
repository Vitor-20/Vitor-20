public class Animal {
    public void som() {
        System.out.println("Fazendo um som genérico de animal");
    }
}

public class Cachorro extends Animal {
    @Override
    public void som() {
        System.out.println("Au au!");
    }
}

public class Gato extends Animal {
    @Override
    public void som() {
        System.out.println("Miau!");
    }
}

public class Main {
    public static void main(String[] args) {
        List<Animal> animais = new ArrayList<>();
        animais.add(new Cachorro());
        animais.add(new Gato());
        animais.add(new Animal());

        for (Animal animal : animais) {
            animal.som();
        }
    }
}