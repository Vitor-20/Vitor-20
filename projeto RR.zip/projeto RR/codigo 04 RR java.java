public class Animal {
    public void som() {
        System.out.println("Fazendo um som genérico de animal");
    }
}

public class Cachorro extends Animal {
    @Override
    public void som() {
        System.out.println("Au au!");
    }
}

public class Gato extends Animal {
    @Override
    public void som() {
        System.out.println("Miau!");
    }
}