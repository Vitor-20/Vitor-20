interface Imprimivel {
    void imprimir();
}

class Relatorio implements Imprimivel {
    @Override
    public void imprimir() {
        System.out.println("Imprimindo relatório...");
    }
}

class Contrato implements Imprimivel {
    @Override
    public void imprimir() {
        System.out.println("Imprimindo contrato...");
    }
}