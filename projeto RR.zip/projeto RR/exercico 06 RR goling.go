package main

import "fmt"

// Professor representa um professor.
type Professor struct {
    nome string
}

// Escola representa uma escola.
type Escola struct {
    nome     string
    professores []Professor
}

// AdicionarProfessor adiciona um professor à escola.
func (e *Escola) AdicionarProfessor(professor Professor) {
    e.professores = append(e.professores, professor)
}

func main() {
    // Criando alguns professores
    professor1 := Professor{nome: "João"}
    professor2 := Professor{nome: "Maria"}

    // Criando duas escolas
    escola1 := Escola{nome: "Colégio Alfa"}
    escola2 := Escola{nome: "Colégio Beta"}

    // Adicionando professores às escolas
    escola1.AdicionarProfessor(professor1)
    escola1.AdicionarProfessor(professor2)
    escola2.AdicionarProfessor(professor2)

    // Imprimindo os professores de cada escola
    fmt.Println("Professores da escola", escola1.nome)
    for _, professor := range escola1.professores {
        fmt.Println(professor.nome)
    }

    fmt.Println("Professores da escola", escola2.nome)
    for _, professor := range escola2.professores {
        fmt.Println(professor.nome)
    }
}