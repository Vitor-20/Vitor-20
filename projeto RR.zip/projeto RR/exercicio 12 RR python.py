class Produto:
    def __init__(self, nome, preco):
        self.nome = nome
        self.preco = preco

    def __add__(self, outro):
        return self.preco + outro.preco

produto1 = Produto("Camiseta", 20.0)
produto2 = Produto("Calça", 50.0)

preco_total = produto1 + produto2
print(preco_total)  # Saída: 70.0