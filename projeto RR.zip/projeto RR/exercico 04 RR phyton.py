Class cachorro(animal)
    def som:(self)
Return: "o cachorro faz au au!"
Class gato(animal)
    def som(self)
Return: "o gato faz miau miau"