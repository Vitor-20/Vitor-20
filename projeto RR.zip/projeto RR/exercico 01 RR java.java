public class carro{
    // atributos da classe carro
    String marca;
    String modelo;
    int ano;

    public class carro(string marca,string modelo,int ano){
        this.marca = marca
        this.modelo = modelo
        this.ano = ano
    }


}

public  void exbirdetales(){
    Systen.out.println("Marca: "+ marca);
     Systen.out.println("Modelo: "+ modelo);
     Systen.out.println("ano: "+ ano);

}