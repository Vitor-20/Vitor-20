vclass Empregado {
    private String nome;
    private String cargo;
    private double salario;

    public Empregado(String nome, String cargo, double salario) {
        this.nome = nome;
        this.cargo = cargo;
        this.salario   
 = salario;
    }

    // ... outros métodos para Empregado
}

class Empresa {
    private String nome;
    private List<Empregado> empregados;

    public Empresa(String nome) {
        this.nome = nome;
        this.empregados = new ArrayList<>();
    }

    public void   
 adicionarEmpregado(Empregado empregado) {
        empregados.add(empregado);
    }

    public void removerEmpregado(Empregado empregado) {
        empregados.remove(empregado);
    }

    // ... outros métodos para Empresa
}

public class Main {
    public static void main(String[] args) {
        // Criando objetos
        Empregado empregado1 = new Empregado("João", "Programador", 5000.0);
        Empregado empregado2 = new Empregado("Maria", "Designer", 4500.0);

        Empresa empresa = new Empresa("TechCorp");
        empresa.adicionarEmpregado(empregado1);
        empresa.adicionarEmpregado(empregado2);

        // Exibindo informações (exemplo)
        System.out.println("Funcionários da " + empresa.nome + ":");
        for (Empregado empregado : empresa.empregados) {
            System.out.println("- " + empregado.nome + " - " + empregado.cargo);
        }
    }
}