package main

import "sync"

type Configuracao struct {
    // ... seus atributos
}

var once sync.Once
var instance *Configuracao

func GetConfiguracao() *Configuracao {
    once.Do(func() {
        instance = &Configuracao{
            // ... inicialização dos atributos
        }
    })
    return instance
}