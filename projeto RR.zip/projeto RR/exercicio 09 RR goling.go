package main

import "fmt"

// Interface Imprimivel define o método Imprimir.
type Imprimivel interface {
    Imprimir()
}

// Relatório implementa a interface Imprimivel.
type Relatorio struct {
    titulo string
    conteudo string
}

func (r Relatorio) Imprimir() {
    fmt.Printf("Relatório:\nTítulo: %s\nConteúdo: %s\n", r.titulo, r.conteudo)
}

// Contrato implementa a interface Imprimivel.
type Contrato struct {
    partes []string
    data    string
}

func (c Contrato) Imprimir() {
    fmt.Println("Contrato:")
    for _, parte := range c.partes {
        fmt.Println(parte)
    }
    fmt.Println("Data:", c.data)
}

func main() {
    relatorio := Relatorio{"Relatório Mensal", "Este é o conteúdo do relatório."}
    contrato := Contrato{[]string{"João", "Maria"}, "01/01/2023"}

    var imprimivel Imprimivel

    imprimivel = relatorio
    imprimivel.Imprimir()

    imprimivel = contrato
    imprimivel.Imprimir()
}