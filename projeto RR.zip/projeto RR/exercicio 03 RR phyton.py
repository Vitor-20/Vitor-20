class ContaBancaria:
    def __init__(self, titular, saldo_inicial=0):
        self.titular = titular
        self.__saldo = saldo_inicial  # Atributo saldo encapsulado (privado)

    # Método para depositar dinheiro
    def depositar(self, valor):
        if valor > 0:
            self.__saldo += valor
            print(f"Depósito de R${valor} realizado com sucesso.")
        else:
            print("O valor do depósito deve ser positivo.")

    # Método para sacar dinheiro
    def sacar(self, valor):
        if 0 < valor <= self.__saldo:
            self.__saldo -= valor
            print(f"Saque de R${valor} realizado com sucesso.")
        else:
            print("Saque inválido. Verifique o valor e o saldo disponível.")

    # Método para exibir o saldo (getter)
    def exibir_saldo(self):
        print(f"Saldo atual: R${self.__saldo:.2f}")


# Exemplo de uso
minha_conta = ContaBancaria("João", 1000)
minha_conta.exibir_saldo()

minha_conta.depositar(500)
minha_conta.exibir_saldo()

minha_conta.sacar(200)
minha_conta.exibir_saldo()

minha_conta.sacar(2000)  # Tentativa de saque maior que o saldo