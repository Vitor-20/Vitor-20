class professor{
    private string nome
    private List<escola> escolas;

    public professor(strng nome){
        this.nome = nome
        this.escola = new ArrayList<>();
    }

    public void adicionarescola(escola escola){
        escolas.add(escola)

    }

}

class escola{
    private string professor
    prisva List<professor> professores;

    public escola(professor){
        this.nome = professor
        this.professor = new Arralist(){

        }
    }

    pubic void(adiconar professor)( professor professor){
        prfessor.add(prfessor)
        professor.adicionarEscola(this)
    }