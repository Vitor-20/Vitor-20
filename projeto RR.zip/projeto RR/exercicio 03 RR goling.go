package main

import "fmt"

// Carro representa um veículo com um atributo velocidade.
type Carro struct {
    velocidade int
}

// Acelerar incrementa a velocidade do carro.
func (c *Carro) Acelerar(valor int) {
    c.velocidade += valor
}

// Frear decrementa a velocidade do carro, mas não permite valores negativos.
func (c *Carro) Frear(valor int) {
    c.velocidade -= valor
    if c.velocidade < 0 {
        c.velocidade = 0
    }
}

// ExibirVelocidade imprime a velocidade atual do carro no console.
func (c *Carro) ExibirVelocidade() {
    fmt.Printf("Velocidade atual: %d km/h\n", c.velocidade)
}

func main() {
    // Cria um novo carro com velocidade inicial 0.
    meuCarro := Carro{}

    // Acelera o carro em 50 km/h.
    meuCarro.Acelerar(50)

    // Exibe a velocidade atual.
    meuCarro.ExibirVelocidade()

    // Freia o carro em 30 km/h.
    meuCarro.Frear(30)

    // Exibe a velocidade atual.
    meuCarro.ExibirVelocidade()
}