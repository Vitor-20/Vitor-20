class Calculadora:
    def somar(self, *args):
        return sum(args)