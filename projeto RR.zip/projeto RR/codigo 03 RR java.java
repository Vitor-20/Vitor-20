public class ContaBancaria {
    private double saldo;
    private String titular;

    // Construtor para inicializar os atributos
    public ContaBancaria(String titular, double saldoInicial) {
        this.titular = titular;
        this.saldo = saldoInicial;
    }

    // Método para depositar um valor
    public void depositar(double valor) {
        if (valor > 0) {
            saldo += valor;
        } else {
            System.out.println("Valor inválido para depósito.");
        }
    }

    // Método para sacar um valor
    public void sacar(double valor) {
        if (valor > 0 && valor <= saldo) {
            saldo -= valor;
        } else {
            System.out.println("Saldo insuficiente ou valor inválido para saque.");
        }
    }

    // Método para obter o saldo (getter)
    public double getSaldo() {
        return saldo;
    }

    // Método para obter o titular (getter)
    public String getTitular() {
        return titular;
    }
}