funcionario1 = FuncionarioHorista("João", "123456789", 20, 180)
funcionario2 = FuncionarioAssalariado("Maria", "987654321", 5000)

print(funcionario1.calcular_salario())  # Saída: 3600
print(funcionario2.calcular_salario())  # Saída: 5000