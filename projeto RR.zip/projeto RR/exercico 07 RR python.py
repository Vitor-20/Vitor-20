class Professor:
    def __init__(self, nome):
        self.nome = nome
        self.escolas = []

    def adicionar_escola(self, escola):
        self.escolas.append(escola)

class Escola:
    def __init__(self, nome):
        self.nome = nome
        self.professores = []

    def adicionar_professor(self, professor):
        self.professores.append(professor)   

        professor.adicionar_escola(self)  # Mantém a associação bidirecional

# Criando instâncias
escola1 = Escola("Colégio Alfa")
escola2 = Escola("Colégio Beta")

professor1 = Professor("João")
professor2 = Professor("Maria")
professor3 = Professor("Pedro")

# Associando professores às escolas
escola1.adicionar_professor(professor1)
escola1.adicionar_professor(professor2)
escola2.adicionar_professor(professor2)
escola2.adicionar_professor(professor3)

# Imprimindo as associações
print(f"Professores da escola {escola1.nome}:")
for professor in escola1.professores:
    print(professor.nome)

print(f"Escolas em que {professor2.nome} leciona:")
for escola in professor2.escolas:
    print(escola.nome)