package main

import "fmt"

type Produto struct {
    Nome  string
    Preco float64
}

func (p Produto) Add(outro Produto) Produto {
    return Produto{
        Nome:  p.Nome + " + " + outro.Nome,
        Preco: p.Preco + outro.Preco,
    }
}

func main() {
    produto1 := Produto{"Camiseta", 20}
    produto2 := Produto{"Calça", 50}
    produtoTotal := produto1.Add(produto2)
    fmt.Printf("%s: R$ %.2f\n", produtoTotal.Nome, produtoTotal.Preco)
}