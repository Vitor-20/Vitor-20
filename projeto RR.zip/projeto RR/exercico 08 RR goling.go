package main

import "fmt"

// Empregado representa um empregado da empresa.
type Empregado struct {
    Nome    string
    Cargo   string
    Salario float64
}

// Empresa representa uma empresa com seus empregados.
type Empresa struct {
    Nome     string
    Empregados []Empregado
}

// AdicionarEmpregado adiciona um novo empregado à empresa.
func (e *Empresa) AdicionarEmpregado(novoEmpregado Empregado) {
    e.Empregados = append(e.Empregados, novoEmpregado)
}

// ListarEmpregados lista todos os empregados da empresa.
func (e *Empresa) ListarEmpregados() {
    for _, empregado := range e.Empregados {
        fmt.Printf("Nome: %s, Cargo: %s, Salário: R$ %.2f\n", empregado.Nome, empregado.Cargo, empregado.Salario)
    }
}

func main() {
    // Criando alguns empregados
    emp1 := Empregado{"João Silva", "Desenvolvedor", 5000.0}
    emp2 := Empregado{"Maria Souza", "Designer", 4500.0}

    // Criando uma empresa
    empresa := Empresa{"TechCorp", []Empregado{emp1}}

    // Adicionando mais um empregado à empresa
    empresa.AdicionarEmpregado(emp2)

    // Listando os empregados da empresa
    fmt.Println("Empregados da empresa", empresa.Nome)
    empresa.ListarEmpregados()
}