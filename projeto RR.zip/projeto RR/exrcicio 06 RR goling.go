package main

import "fmt"

// Motor representa um motor de um carro.
type Motor struct {
    potencia int
}

// Ligar o motor.
func (m *Motor) Ligar() {
    fmt.Println("Motor ligado!")
}

// Desligar o motor.
func (m *Motor) Desligar() {
    fmt.Println("Motor desligado!")
}

// Carro representa um carro com um motor.
type Carro struct {
    modelo  string
    motor   Motor
    ligado  bool
}

// Ligar o carro.
func (c *Carro) Ligar() {
    c.motor.Ligar()
    c.ligado = true
    fmt.Println("Carro ligado!")
}

// Desligar o carro.
func (c *Carro) Desligar() {
    c.motor.Desligar()
    c.ligado = false
    fmt.Println("Carro desligado!")
}

func main() {
    // Criando um motor com 150 cavalos de potência.
    motor := Motor{potencia: 150}

    // Criando um carro com o motor criado.
    carro := Carro{modelo: "Gol", motor: motor}

    // Ligando e desligando o carro.
    carro.Ligar()
    carro.Desligar()
}