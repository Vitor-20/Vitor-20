package main

import "fmt"

type carro struct{
	marca string
	modelo string
	int ano


}

func (c carro) exibirdetalhes(){
	fmt.prinf("Marca: %s, Modelo: %s, Ano: d/n" c.marca c.modelo.c.ano)

}

func main(){
	carro1 : = carro{Marca: "Toyota", Modelo: "Corolla", Ano: 2020}
	carro2 = carro{Marca: "Fiat", Modelo: Toro, Ano: 2019}
	carro3 = carro{Marca: "Jeep", Mdelo: Compass, Ano 2023}
}