public class carro()
string marca;
string modelo;
int ano;
int velocidade;

public class carro(string marca,string modelo, int ano, int velocidade)
       this.marca;
       this.modelo;
       this.ano;
       this.velocidade = 0;

public class freiar(){
    velocidade-=10;
    if(velocidade < 0){
        velocidade  = 0 // impede a velocidade de ficar negativa
    }
}  

System.ou.println("freando... Velocidade atual:"+ velocidade)

public void exibirvelocidades(){
    Systen.out.pritln("Marca: "+ marca)
    Systen.out.pritln("Modelo:"+ modelo)
    Systen.out.println("ano:"+ ano)

}