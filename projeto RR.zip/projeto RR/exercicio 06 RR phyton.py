class Motor:
    def __init__(self, potencia, cilindrada):
        self.potencia = potencia
        self.cilindrada = cilindrada

    def ligar(self):
        print("Motor ligado!")

    def desligar(self):
        print("Motor desligado!")

class Carro:
    def __init__(self, marca, modelo, motor):
        self.marca = marca
        self.modelo = modelo
        self.motor = motor

    def acelerar(self):
        print("Carro acelerando...")
        self.motor.ligar()

    def frear(self):
        print("Carro freando...")
        self.motor.desligar()

# Criando um objeto Motor
motor1 = Motor(150, 1.6)

# Criando um objeto Carro, associando o motor criado
carro1 = Carro("Toyota", "Corolla", motor1)

# Utilizando os métodos
carro1.acelerar()
carro1.frear()