package main

import "fmt"

// Interface Funcionario define o contrato para todos os funcionários.
type Funcionario interface {
    CalcularSalario() float64
}

// FuncionarioHorista implementa a interface Funcionario.
type FuncionarioHorista struct {
    nome     string
    valorHora float64
    horasTrabalhadas int
}

func (f FuncionarioHorista) CalcularSalario() float64 {
    return f.valorHora * float64(f.horasTrabalhadas)
}

// FuncionarioAssalariado implementa a interface Funcionario.
type FuncionarioAssalariado struct {
    nome     string
    salario fixo float64
}

func (f FuncionarioAssalariado) CalcularSalario() float64 {
    return f.salario
}

func main() {
    // Criando instâncias de funcionários
    horista := FuncionarioHorista{"João", 20, 160}
    assalariado := FuncionarioAssalariado{"Maria", 5000}

    // Calculando e imprimindo os salários
    fmt.Printf("Salário de %s (horista): R$ %.2f\n", horista.nome, horista.CalcularSalario())
    fmt.Printf("Salário de %s (assalariado): R$ %.2f\n", assalariado.nome, assalariado.Assalariado)
}