package main

import "errors"

type SaldoInsuficienteError struct {
    message string
}

func (e *SaldoInsuficienteError) Error() string {
    return e.message
}

type ContaBancaria struct {
    saldo float64
}

func (c *ContaBancaria) Sacar(valor float64) error {
    if valor > c.saldo {
        return &SaldoInsuficienteError{"Saldo insuficiente para o saque."}
    }
    // ... lógica para realizar o saque
    return nil
}