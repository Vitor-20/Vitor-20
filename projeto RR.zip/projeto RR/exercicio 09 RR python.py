
from abc import ABC, abstractmethod

class Imprimivel(ABC):
    @abstractmethod
    def imprimir(self):
        pass

class Relatorio(Imprimivel):
    def __init__(self, conteudo):
        self.conteudo = conteudo

    def imprimir(self):
        print(self.conteudo)

class Contrato(Imprimivel):
    def __init__(self, partes, clausulas):
        self.partes = partes
        self.clausulas = clausulas

    def imprimir(self):
        print("Contrato entre:", self.partes)
        print("Cláusulas:", self.clausulas)

# Usando as classes
relatorio = Relatorio("Este é um relatório.")
contrato = Contrato(["João", "Maria"], ["Pagamento", "Prazo"])

relatorio.imprimir()
contrato.imprimir()
