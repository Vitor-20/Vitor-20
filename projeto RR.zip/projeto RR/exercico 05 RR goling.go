package main

import "fmt"

// Interface Animal define um contrato para os animais.
type Animal interface {
    Som()
}

// Estrutura base para todos os animais.
type animalBase struct {
    nome string
}

// Cachorro implementa a interface Animal.
type Cachorro struct {
    animalBase
}

// Gato implementa a interface Animal.
type Gato struct {
    animalBase
}

// Implementação do método Som para Cachorro.
func (c Cachorro) Som() {
    fmt.Println("Au au!")
}

// Implementação do método Som para Gato.
func (g Gato) Som() {
    fmt.Println("Miau!")
}

// Função para fazer todos os animais fazerem som.
func fazerTodosOsAnimaisFazeremSom(animais []Animal) {
    for _, animal := range animais {
        animal.Som()
    }
}

func main() {
    // Criando uma lista de animais
    animais := []Animal{
        Cachorro{animalBase{"Rex"}},
        Gato{animalBase{"Mia"}},
        Cachorro{animalBase{"Spike"}},
    }

    // Chamando a função para todos os animais fazerem som
    fazerTodosOsAnimaisFazeremSom(animais)
}