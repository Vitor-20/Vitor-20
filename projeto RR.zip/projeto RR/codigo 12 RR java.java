class Produto {
    private String nome;
    private double preco;

    // ... construtores e getters/setters

    public Produto somar(Produto outro) {
        return new Produto("Soma", this.preco + outro.preco);
    }
}