package main

import "fmt"

type carro{
	marca string
	modelo string
	ano int
	velocidade int

	func main(c carro) acelerar(){
		c velocidade += 10
		fmt.print("o carro acelerou %s %s, velocidade atual km/h" c.marca c.modelo c.ano)

	}

	func main(c carro) exibirvelocidade(){
		fmt.print("velocidade atual %s %s: %d km/h" c.marca c.modelo c.ano)

		carro = {Marca: "Toyota", Modelo: "Corolla", ano: 2023}
	}

}

