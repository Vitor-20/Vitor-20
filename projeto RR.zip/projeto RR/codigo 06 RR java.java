public class Motor {
    private int potencia;

    public Motor(int potencia) {
        this.potencia = potencia;
    }

    public void ligar() {
        System.out.println("Motor ligado!");
    }

    public void desligar() {
        System.out.println("Motor desligado!");
    }
}

public class Carro {
    private String modelo;
    private Motor motor;

    public Carro(String modelo, Motor motor) {
        this.modelo = modelo;
        this.motor = motor;
    }

    public   
 void acelerar() {
        motor.ligar();
        System.out.println("Carro acelerando!");
    }
}

public class Main {
    public static void main(String[] args) {
        Motor motor1 = new Motor(200);
        Carro carro1 = new Carro("Gol", motor1);

        carro1.acelerar();
    }
}